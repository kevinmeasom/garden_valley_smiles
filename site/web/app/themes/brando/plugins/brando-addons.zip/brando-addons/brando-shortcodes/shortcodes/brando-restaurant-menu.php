<?php
/**
 * Shortcode For Restaurant Menu
 *
 * @package Brando
 */
?>
<?php 
/*-----------------------------------------------------------------------------------*/
/* Restaurant Menu */
/*-----------------------------------------------------------------------------------*/

function brando_restaurant_menu_shortcode( $atts, $content = null ) 
{
    extract( shortcode_atts( array(
                'id' => '',
                'class' => '',
                'brando_menu_bg_image' => '',
                'brando_menuitem_bg_image' => '',
                'brando_menu_image' => '',
                'brando_title' => '',
                'brando_subtitle' => '',
                'brando_menu_sep_image' => '',
                'brando_title_color' => '',
                'brando_subtitle_color' => '',
                'brando_menu_border_color' => '',
                'brando_image_srcset' => 'full',
                'brando_menu_image_srcset' => 'full',
                'title_settings' => '',
                'subtitle_settings' => ''
            ), $atts ) );
    global $font_settings_array;
    $output = $bg_image = $menuitem_bg_image = '';
    $id = ($id) ? ' id='.$id : '';
    $class = ($class) ? ' '.$class : '';

    $brando_bg_image = ( $brando_menu_bg_image ) ? wp_get_attachment_image_src($brando_menu_bg_image, $brando_image_srcset) : '';
    $brando_menuitem_bg_image = ( $brando_menuitem_bg_image ) ? wp_get_attachment_image_src($brando_menuitem_bg_image, 'full') : '';

    $brando_menu_image_srcset = ($brando_menu_image_srcset) ? $brando_menu_image_srcset : 'full';

    $brando_title_color = ( $brando_title_color ) ? ' style="color:'.$brando_title_color.' !important;"' : '';
    $brando_subtitle_color = ( $brando_subtitle_color ) ? ' style="color:'.$brando_subtitle_color.' !important;"' : '';
    $brando_menu_border_color = ( $brando_menu_border_color ) ? ' style="border-color:'.$brando_menu_border_color.' !important;"' : '';
    $brando_image_srcset = ($brando_image_srcset) ? $brando_image_srcset : 'full';
    $srcset = $srcset_data = $classes = '';
    if( isset($brando_bg_image[0]) )
    {
        $srcset = wp_get_attachment_image_srcset( $brando_menu_bg_image, $brando_image_srcset );
        if( $srcset ){
            $srcset_data = ' data-bg-srcset="'.esc_attr( $srcset ).'"';
            $classes = ' bg-image-srcset';
        }
        $bg_image .= ' style="background-image: url('.$brando_bg_image[0].');"';
    }
    if( isset($brando_menuitem_bg_image[0]) )
    {
        $menuitem_bg_image .= ' style="background-image: url('.$brando_menuitem_bg_image[0].');"';
    }

    //Font Settings For Title
    $fontsettings_title_class = $fontsettings_title_id = $responsive_style = '';
    if( !empty( $title_settings ) ) {
        $fontsettings_title_id = uniqid('brando-font-setting-');
        $responsive_style = brando_Responsive_font_settings::generate_css( $title_settings, $fontsettings_title_id );
        $fontsettings_title_class = ' '.$fontsettings_title_id;
    }
    ( !empty( $responsive_style ) ) ? $font_settings_array[] = $responsive_style : '';

    //Font Settings For Title
    $fontsettings_subtitle_class = $fontsettings_subtitle_id = $responsive_style_subtitle = '';
    if( !empty( $subtitle_settings ) ) {
        $fontsettings_subtitle_id = uniqid('brando-font-setting-');
        $responsive_style_subtitle = brando_Responsive_font_settings::generate_css( $subtitle_settings, $fontsettings_subtitle_id );
        $fontsettings_subtitle_class = ' '.$fontsettings_subtitle_id;
    }
    ( !empty( $responsive_style_subtitle ) ) ? $font_settings_array[] = $responsive_style_subtitle : '';

        $output .= '<div'.$id.' class="restaurant-menu'.$class.'">';
            $output .= '<div class="restaurant-menu-image cover-background'.$classes.'"'.$bg_image.$srcset_data.'>';
                
                $output .= '<div class="restaurant-menu-background">';

                    $output .= '<div class="restaurant-menu-border z-index-1"></div>';

                    $output .= '<div class="restaurant-menu-item z-index-2">';
                        if( isset( $brando_menu_image ) ){
                            $output .= wp_get_attachment_image( $brando_menu_image, $brando_menu_image_srcset );
                        }
                        if( $brando_title ){
                            $output .= '<span class="title-small alt-font deep-yellow-text font-weight-600 text-uppercase display-block margin-three-top'.$fontsettings_title_class.'"'.$brando_title_color.'>'.$brando_title.'</span>';
                        }
                        if( $brando_subtitle ){
                            $output .= '<span class="text-small letter-spacing-1 text-uppercase'.$fontsettings_subtitle_class.'"'.$brando_subtitle_color.'>'.$brando_subtitle.'</span>';
                        }
                        if( isset( $brando_menu_sep_image ) ){
                            $output .= '<div class="margin-three-tb">';
                                $output .= wp_get_attachment_image( $brando_menu_sep_image, 'full' );
                            $output .= '</div>';
                        }
                    $output .= '</div>';
                $output .= '</div>';
            $output .= '</div>';

            $output .= '<div class="restaurant-menu-text"'.$brando_menu_border_color.'>';
                $output .= '<div class="restaurant-menu-text-inner padding-seven-all sm-padding-five-all"'.$menuitem_bg_image.'>';
                    $output .= do_shortcode($content);
                $output .= '</div>';
            $output .= '</div>';
        $output .= '</div>';
    return $output;
}
add_shortcode( 'brando_restaurant_menu', 'brando_restaurant_menu_shortcode' );
 
function brando_restaurant_menu_content_shortcode( $atts, $content = null) 
{
	global $brando_slider_parent_type, $font_settings_array;
    extract( shortcode_atts( array(
                'brando_menuitem_image' => '',
                'brando_menuitem_title' => '',
                'brando_menuitem_title_color' => '',
                'title_settings' => '',
            ), $atts ) );
    $output = '';
    $brando_menuitem_title = ( $brando_menuitem_title ) ? $brando_menuitem_title : '';
    $brando_menuitem_title_color = ( $brando_menuitem_title_color ) ? ' style="color:'.$brando_menuitem_title_color.' !important;"' : '';

    //Font Settings For Title
    $fontsettings_title_class = $fontsettings_title_id = $responsive_style = '';
    if( !empty( $title_settings ) ) {
        $fontsettings_title_id = uniqid('brando-font-setting-');
        $responsive_style = brando_Responsive_font_settings::generate_css( $title_settings, $fontsettings_title_id );
        $fontsettings_title_class = ' '.$fontsettings_title_id;
    }
    ( !empty( $responsive_style ) ) ? $font_settings_array[] = $responsive_style : '';

        $output .= '<div class="menu-item">';
        if( isset( $brando_menuitem_image ) )
        {
            $output .= '<div class="col-md-3 col-sm-2 col-xs-3 menu-img sm-display-block">';
                $output .= wp_get_attachment_image( $brando_menuitem_image, 'full', '', array( 'class' => 'round-border' ) );
            $output .= '</div>';
        }
            $output .= '<div class="col-md-8 col-sm-8 col-xs-7 col-xs-8 menu-text sm-width-80 xs-width-70">';
                $output .= '<div class="menu-text-sub">';
                    if( $brando_menuitem_title ){
                        $output .= '<span class="text-uppercase brown-text letter-spacing-1 display-block font-weight-600 md-padding-one-top'.$fontsettings_title_class.'"'.$brando_menuitem_title_color.'>'.$brando_menuitem_title.'</span>';
                    }
                    if( $content ){
                        $output .= do_shortcode( brando_remove_wpautop($content) );
                    }
                $output .= '</div>';
            $output .= '</div>';
        $output .= '</div>';
    return $output;
}
add_shortcode( 'brando_restaurant_menu_content', 'brando_restaurant_menu_content_shortcode' );