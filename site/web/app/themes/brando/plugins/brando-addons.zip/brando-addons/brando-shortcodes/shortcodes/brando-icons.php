<?php
/**
 * Shortcode For Icon
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Icons */
/*-----------------------------------------------------------------------------------*/
add_shortcode('brando_font_icons','brando_font_icons_shortcode');
if ( ! function_exists( 'brando_font_icons_shortcode' ) ) {
    function brando_font_icons_shortcode( $atts, $content = null ) {
    	extract( shortcode_atts( array(
            	'id' => '',
            	'class' => '',
            	'brando_font_icon_type' => '',
                'brando_et_icon_premade_style' => '',
                'brando_font_icon_premade_style' => '',
            	'brando_font_awesome_icon_list' => '',
            	'brando_et_line_icon_list' => '',
            	'brando_font_icon_size' => '',
            	'show_border' => '',
            	'show_border_rounded' => '',
            	'brando_icon_box_size' => '',
            	'brando_icon_box_decoration' => '',
            	'brando_icon_box_background_color' => '',
            	// et icons
            	'brando_et_icon_box_size' => '',
            	'et_show_border' => '',
            	'show_et_border_rounded' => '',
            	'et_plain' => '',
            	'circled' => '',
            	'brando_et_icon_box_decoration' => '',
            	'brando_et_icon_box_background_color' => '',
                'font_awesome_custom_icon' => '',
                'font_awesome_custom_icon_image' => '',
                'etline_custom_icon' => '',
                'etline_custom_icon_image' => '',
                'brando_custom_image_srcset' => 'full',
                'brando_custom_etline_image_srcset' => 'full',
            ), $atts ) );
    	$output = $icon_common_class = '';
        $classes = $style_array = array();
        $id = ( $id ) ? $id : '';
        $class = ( $class ) ? $classes[] = $class : '';
      
        $brando_font_icon_type = ( $brando_font_icon_type ) ? $brando_font_icon_type : '';
    	$brando_font_awesome_icon_list = ( $brando_font_awesome_icon_list ) ?  $brando_font_awesome_icon_list : '';
        //New Font Awesome Icons
        $fa_icons_solid = brando_fontawesome_solid();
        $fa_icons_reg = brando_fontawesome_reg();
        $fa_icons_brand = brando_fontawesome_brand();
        $fa_icon_old = brando_fontawesome_old();
        $font_awesome_fa_icons = explode(' ',trim($brando_font_awesome_icon_list));

        if($font_awesome_fa_icons[0] == 'fa'){
            $brando_font_awesome_icon_list = substr(strstr($brando_font_awesome_icon_list," "), 1);

            if(array_key_exists($brando_font_awesome_icon_list, $fa_icon_old)){
                foreach ($fa_icon_old as $key => $value) {
                    if($brando_font_awesome_icon_list == $key){
                        $brando_font_awesome_icon_list = $value;
                        break;
                    }
                }
            }else if(in_array($brando_font_awesome_icon_list, $fa_icons_solid)){
                $brando_font_awesome_icon_list = 'fas '.$brando_font_awesome_icon_list;
            }else if(in_array($brando_font_awesome_icon_list, $fa_icons_reg)){
                $brando_font_awesome_icon_list = 'far '.$brando_font_awesome_icon_list;
            }else if(in_array($brando_font_awesome_icon_list, $fa_icons_brand)){
                $brando_font_awesome_icon_list = 'fab '.$brando_font_awesome_icon_list;
            }else{
                $brando_font_awesome_icon_list = '';
            }
        }

    	$brando_font_icon_size = ( $brando_font_icon_size ) ? $classes[] = $brando_font_icon_size : '';
        $et_line = ($brando_et_icon_premade_style) ? 'icon-box' : '';
    	$show_border = ( $show_border ) ? $classes[] = 'i-bordered' : '';
    	$show_border_rounded = ( $show_border_rounded ) ? $classes[] = 'i-rounded' : '';
    	$brando_icon_box_size = ( $brando_icon_box_size ) ? $classes[] = $brando_icon_box_size : '';
    	$brando_icon_box_decoration = ( $brando_icon_box_decoration ) ? $classes[] = $brando_icon_box_decoration : '';
    	$brando_icon_box_background = ( $brando_icon_box_background_color ) ?  $classes[] = $brando_icon_box_background_color : '';
    	// Et Line icons
    	$brando_et_line_icon_list = ( $brando_et_line_icon_list ) ? $classes[] = $brando_et_line_icon_list : '';
    	$brando_et_icon_box_size = ( $brando_et_icon_box_size ) ? $classes[] = $brando_et_icon_box_size : '';
    	$et_show_border = ( $et_show_border ) ? $classes[] = 'i-bordered' : '';
    	$show_et_border_rounded = ( $show_et_border_rounded ) ? $classes[] ='i-rounded' : '';
    	$et_plain = ( $et_plain ) ? $classes[] = 'i-plain' : '';
    	$circled = ( $circled ) ? $classes[] = 'i-circled' : '';
    	$brando_et_icon_box_decoration = ( $brando_et_icon_box_decoration ) ? $classes[] = $brando_et_icon_box_decoration : '';
    	$brando_et_icon_box_background_color = ( $brando_et_icon_box_background_color ) ? $classes[] = $brando_et_icon_box_background_color : '';

        // custom icon image
        $brando_custom_etline_image_srcset = ($brando_custom_etline_image_srcset) ? $brando_custom_etline_image_srcset : 'full';

        // font-awesome custom icon image
        $brando_custom_image_srcset = ($brando_custom_image_srcset) ? $brando_custom_image_srcset : 'full';
        
        // ET-Line
        switch ($brando_et_icon_premade_style){
          
            case 'et-line-icons-1':
            case 'et-line-icons-2':
            case 'et-line-icons-3':
            case 'et-line-icons-4':
            case 'et-line-icons-5':
                $classes[]  = '';
            break;
            case 'et-line-icons-6':
                $classes[]  = 'i-background-box ';
            break;
            case 'et-line-icons-7':
            case 'et-line-icons-8':
            case 'et-line-icons-9':
            case 'et-line-icons-10':
            case 'et-line-icons-11':
                $classes[] = '';
            break;
            case 'et-line-icons-12':
                $classes[] = 'i-background-box ';
            break;
        }
        // Font-Awesome
        switch ($brando_font_icon_premade_style){
            case 'font-awesome-icons-1':
            case 'font-awesome-icons-2':
            case 'font-awesome-icons-3':
            case 'font-awesome-icons-4':
                $classes[] = '';
            break;
            case 'font-awesome-icons-5':
                $classes[] = 'i-background-box ';
            break;
        }
        // Check For Font Type
        $class_li = implode(" ", $classes);     
        $class_list = ( $class_li || $brando_font_awesome_icon_list) ? ' class="'.$class_li.$brando_font_awesome_icon_list.'"' : '';       

    	switch ($brando_font_icon_type) 
        {
    		case 'brando_font_awesome_icons':
                if( $font_awesome_custom_icon == 1 && !empty( $font_awesome_custom_icon_image ) ){
                    $output .= wp_get_attachment_image( $font_awesome_custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image '.$class_li, 'id' => $id ) );
                }elseif( $class_list ){
                    $output .= '<i id="'.$id.'"'.$class_list.'></i>';
                }
    		break;
    		case 'brando_et_line_icons':
                if( $etline_custom_icon == 1 && !empty( $etline_custom_icon_image ) ) {
                    $output .= wp_get_attachment_image( $etline_custom_icon_image, $brando_custom_etline_image_srcset, '', array( 'class' => 'icon-image '.$class_li, 'id' => $id ) );
                }elseif( $class_list ){
                    $output .= '<i id="'.$id.'"'.$class_list.'></i>';
                }
    		break;
    	}
        return $output;
    }
}